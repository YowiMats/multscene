Developed using Eqela (www.eqela.com)
